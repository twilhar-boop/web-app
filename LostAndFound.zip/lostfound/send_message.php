<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sender_id   = $_SESSION['user_id'];
    $receiver_id = $_POST['receiver_id'];
    $report_id   = $_POST['report_id'];
    $content     = $_POST['content'];

    // Insert message
    $sql = "INSERT INTO Messages (sender_id, receiver_id, report_id, content) 
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiis", $sender_id, $receiver_id, $report_id, $content);
    $stmt->execute();

    // Insert notification for receiver
    $sql_notify = "INSERT INTO Notifications (user_id, report_id, message) 
                   VALUES (?, ?, ?)";
    $stmt_notify = $conn->prepare($sql_notify);
    $notify_msg = "You received a new message regarding report #$report_id.";
    $stmt_notify->bind_param("iis", $receiver_id, $report_id, $notify_msg);
    $stmt_notify->execute();

    echo "Message sent successfully! <a href='inbox.php'>Go to Inbox</a>";
}
?>
