<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$report_id = intval($_GET['report_id']);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Claim Item</title>
    <link rel="stylesheet" href="css/claim.css">
</head>
<body>
    <div class="claim-form">
    <h2>Claim Report #<?php echo $report_id; ?></h2>

    <form method="POST" action="claim_item.php">
        <input type="hidden" name="report_id" value="<?php echo $report_id; ?>">
        <textarea name="claim_details" placeholder="Explain why this item belongs to you..." required></textarea><br>
        <button type="cancel"><a class="cancelbtn" href="view_reports.php">Cancel</a></button>
        <button type="submit">Submit Claim</button>
    </form></div>
</body>
</html>
