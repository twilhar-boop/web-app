
<!DOCTYPE html>
<html>
    <head><title>LOST AND FOUND</title></head>
    <link rel="stylesheet" href="css/intro.css">
    <body >
        <div class="intro">
        <h1>Welcome to the Lost and Found Management System
        <p>Report lost items, find your belongings, and connect with others in your community.</p></h1>
        <a href="login.php" id="getStartedLink">Get Started</a>
        </div>
    </body>
</html>

<script>
document.getElementById('getStartedLink').addEventListener('click', function (e) {
  e.preventDefault(); // stop immediate navigation
  document.body.classList.add('slide-up');
  setTimeout(() => {
    window.location.href = this.href;
  }, 600); // delay matches animation duration
});
</script>
