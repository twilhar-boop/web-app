<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];

// Helper function for user-friendly date and time
function formatDateTime($datetime) {
    $time = strtotime($datetime);
    return date("F j, Y g:i A", $time);
}

// Fetch notifications
$sql = "SELECT notification_id, message, created_at 
        FROM Notifications 
        WHERE user_id=? 
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Count total notifications
$sql_count = "SELECT COUNT(*) AS notif_count 
              FROM Notifications 
              WHERE user_id=?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param("i", $user_id);
$stmt_count->execute();
$count_result = $stmt_count->get_result();
$count_row = $count_result->fetch_assoc();
$notif_count = $count_row['notif_count'];

// Handle search input
$search = "";
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

// Base query for reports
$sql_reports = "SELECT r.report_id, u.username, i.category, i.description, i.photo_url, i.location, 
                       r.report_type, r.created_at, r.status
                FROM Reports r
                JOIN Users u ON r.user_id = u.user_id
                JOIN Items i ON r.item_id = i.item_id";

// Add search filter if provided
if (!empty($search)) {
    $sql_reports .= " WHERE i.category LIKE ? OR i.description LIKE ? OR u.username LIKE ? OR i.location LIKE ?";
}
if (isset($_GET['missing'])) {
    $sql_reports .= " WHERE r.report_type='Missing'";
} elseif (isset($_GET['found'])) {
    $sql_reports .= " WHERE r.report_type='Found'";
}

$sql_reports .= " ORDER BY r.created_at DESC";

$stmt_reports = $conn->prepare($sql_reports);

if (!empty($search)) {
    $like = "%$search%";
    $stmt_reports->bind_param("ssss", $like, $like, $like, $like);
}

$stmt_reports->execute();
$reports_result = $stmt_reports->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>LOST AND FOUND</title>
    <link rel="stylesheet" href="css/view.css">
</head>
<body>

    <!-- Notifications sidebar -->
    <div id="notif_overlay" class="notif-overlay">
        <div class="notif-content">
            <span id="close_overlay">&times;</span>
            <h3>Your Notifications</h3>
            <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<p>{$row['message']} (" . formatDateTime($row['created_at']) . ")</p>";
                    }
                } else {
                    echo "<p>No notifications yet.</p>";
                }
            ?>
        </div>
    </div>

    <h2>Lost/Found Items</h2>
    <!-- Search bar -->
    <form method="GET" class="search-form">
        <input class="search" type="text" name="search" placeholder="Search reports by user, category, description, or location..." 
               value="<?php echo htmlspecialchars($search); ?>">
                <button class="btnsearch" type="submit">Search</button>
                <button name="missing" type="submit" class="btnsearchfil">Missing Items</button>
                <button name="found" type="submit" class="btnsearchfil">Found Items</button>
    </form>

    <div class="reports">
     <?php
        if ($reports_result->num_rows > 0) {
            while ($row = $reports_result->fetch_assoc()) {
             echo "<div class='report-box'>";
                echo "<b>{$row['report_type']}:</b> {$row['category']} - {$row['description']}<br>";

                // Show photo if available, otherwise show placeholder
                if (!empty($row['photo_url'])) {
                    echo "<img src='{$row['photo_url']}' alt='Item photo'>";
                } else {
                    echo "<img src='images/placeholder.png' alt='No photo uploaded'>";
                }

                echo "<small>by {$row['username']} on " . formatDateTime($row['created_at']) . "</small><br>";
                echo "<small>Report ID: {$row['report_id']} </small><br>";
                echo "<small>Location: " . (!empty($row['location']) ? htmlspecialchars($row['location']) : 'N/A') . "</small><br>";

                // Proper Claim button that redirects to another form
                if (strcasecmp($row['status'], 'Claimed') === 0) {
                    // Disabled button if already claimed
                    echo "<button type='button' disabled class='claim-btn' style='background:#aaa;cursor:not-allowed;'>Already Claimed</button>";
                } else {
                    // Active claim button
                    echo "<button type='button'><a class='claim-btn' href='claim_form.php?report_id={$row['report_id']}'>Claim Item</a></button>";
                }


                echo "</div>";

            }
        } else {
            if (!empty($search)) {
                echo "<p>No reports found for '".htmlspecialchars($search)."'.</p>";
            } else {
                echo "<p>No reports found.</p>";
            }
        }
        ?>
    </div>

    <script>
    document.getElementById("notif_toggle").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.add("open");
    });
    document.getElementById("close_overlay").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.remove("open");
    });
    </script>
</body>
</html>
