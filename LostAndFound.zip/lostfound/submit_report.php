<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];

// Fetch notifications (no status column anymore)
$sql = "SELECT notification_id, message, created_at 
        FROM Notifications 
        WHERE user_id=? 
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Count total notifications
$sql_count = "SELECT COUNT(*) AS notif_count 
              FROM Notifications 
              WHERE user_id=?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param("i", $user_id);
$stmt_count->execute();
$count_result = $stmt_count->get_result();
$count_row = $count_result->fetch_assoc();
$notif_count = $count_row['notif_count'];


// Helper function for user-friendly date and time
function formatDateTime($datetime) {
    $time = strtotime($datetime);
    return date("F j, Y g:i A", $time);
}


// Handle report submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category    = $_POST['category'];
    $description = $_POST['description'];
    $location    = $_POST['location'];
    $status      = $_POST['status']; 
    $photo_url   = null;

    // Handle photo upload 
    if (!empty($_FILES['photo']['name'])) {
        $target_dir  = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $filename     = time() . "_" . basename($_FILES["photo"]["name"]);
        $target_file  = $target_dir . $filename;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $allowed_types = ["jpg", "jpeg", "png", "gif"];
        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                $photo_url = $target_file;
            }
        }
    }

    // Insert item
    $sql_item = "INSERT INTO Items (category, description, location, status, photo_url) VALUES (?, ?, ?, ?, ?)";
    $stmt_item = $conn->prepare($sql_item);
    $stmt_item->bind_param("sssss", $category, $description, $location, $status, $photo_url);
    $stmt_item->execute();
    $item_id = $stmt_item->insert_id;

    // Insert report
    $sql_report = "INSERT INTO Reports (user_id, item_id, report_type) VALUES (?, ?, ?)";
    $stmt_report = $conn->prepare($sql_report);
    $stmt_report->bind_param("iis", $user_id, $item_id, $status);
    $stmt_report->execute();

    echo "Report submitted successfully!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Lost and Found</title>
    <link rel="stylesheet" href="css/submit.css">
</head>
<body>
   


    <div class="submitform">
        <form method="POST" enctype="multipart/form-data">
            <h1> Report an Item </h1>
            <hr>
            <table >
                <tr>
                    <td><label for="status">Status:</label></td>
                    <td><label for="photo">Photo:</label></td>
                </tr>
                <tr>
                    <td>
                        <select name="status" class="sub">
                            <option value="missing">Missing</option>
                            <option value="found">Found</option>
                        </select>                      
                    </td>
                    <td><input type="file" name="photo" placeholder="Choose a photo" accept="image/*" required></td>
                </tr>
                <tr>
                    <td><label for="category">Category(e.g. Electronics, Card, Wallet, Cash):</label></td>
                    <td><label for="location">Location Lost/Found (specify):</label></td>                
                </tr>
                <tr>
                    <td><input type="text" name="category" placeholder="item type or name" required></td>
                    <td><input type="text" name="location" placeholder="location where item was lost or found" required></td>                   
                </tr>
                <tr>
                    <td><label for="description">Description:</label></td>      
                </tr>
                <tr>
                    <td><textarea name="description" placeholder="detailed description" required></textarea></td>
                </tr>
            </table><br><br>
            <div class="btns">
            <button type="reset">Cancel</button>
            <button type="submit">Submit Report</button>
            </div>
        </form>
    </div>

            <!-- Notifications sidebar -->
    <div id="notif_overlay" class="notif-overlay">
        <div class="notif-content">
            <span id="close_overlay">&times;</span>
            <h2>Your Notifications</h2>
            <?php
                if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                echo "<p>{$row['message']} (" . formatDateTime($row['created_at']) . ")</p>";
                }
        }  else {
                echo "<p>No notifications yet.</p>";
        }
        ?>
        </div>
    </div>

    <script>
    document.getElementById("notif_toggle").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.add("open");
    });
    document.getElementById("close_overlay").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.remove("open");
    });
    </script>
</body>
</html>
