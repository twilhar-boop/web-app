<?php
session_start();
include 'db.php';

// If user is not logged in, return 0
if (!isset($_SESSION['user_id'])) {
    echo 0;
    exit();
}

$user_id = $_SESSION['user_id'];

// Count unread notifications for this user
$sql = "SELECT COUNT(*) AS unread_count 
        FROM Notifications 
        WHERE user_id=? AND status='unread'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// Output the count (AJAX will read this)
echo $row['unread_count'];
?>
