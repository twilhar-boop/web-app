<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];


// Fetch username from database
$stmt = $conn->prepare("SELECT username FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$username = $user['username'];


// Helper function for user-friendly date and time
function formatDateTime($datetime) {
    $time = strtotime($datetime);
    return date("F j, Y g:i A", $time);
}


// Fetch notifications (no status column anymore)
$sql = "SELECT notification_id, message, created_at 
        FROM Notifications 
        WHERE user_id=? 
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Count total notifications
$sql_count = "SELECT COUNT(*) AS notif_count 
              FROM Notifications 
              WHERE user_id=?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param("i", $user_id);
$stmt_count->execute();
$count_result = $stmt_count->get_result();
$count_row = $count_result->fetch_assoc();
$notif_count = $count_row['notif_count'];
?>

<!DOCTYPE html>
<html>
    <title>Home</title>
    <link rel="stylesheet" href="css/userdash.css">
    <body>
        <div class="userdash">
        <nav>
        <a href="dashboard.php"  target="frame"> HOME</a>
            <a href="submit_report.php"  target="frame">SUBMIT REPORT</a> 
            <a href="view_reports.php"  target="frame">VIEW ITEMS</a> 
            <a href="messages.php" target="frame" >CONTACT ADMIN</a> 
            <a href="my_reports.php"  target="frame">MY REPORTS</a> 
            <a href="profile.php"  target="frame">MY PROFILE</a> 
            <a href="login.php" >LOGOUT</a>

             <!-- Notifications button -->
            <button id="notif_toggle" class="notif-btn">
                Notifications <span id="notif_count" class="badge"><?php echo $notif_count; ?></span>
            </button>
</nav></div>

            <!-- Notifications sidebar -->
            <div id="notif_overlay" class="notif-overlay">
                <div class="notif-content">
                    <span id="close_overlay">&times;</span>
                    <h2>Your Notifications</h2>
                    <?php
                        if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                        echo "<p>{$row['message']} (" . formatDateTime($row['created_at']) . ")</p>";
                        }
                }  else {
                        echo "<p>No notifications yet.</p>";
                }
                ?>
                </div>
            </div>

    <iframe name="frame" src="dashboard.php" style="width:100%; height:100vh; border:none;"></iframe>
        
    </body>
</html>

    <script>
    document.getElementById("notif_toggle").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.add("open");
    });
    document.getElementById("close_overlay").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.remove("open");
    });
    </script>