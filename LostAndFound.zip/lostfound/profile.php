<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

/* =========================
   FETCH USER INFO
========================= */
$sql = "SELECT username, email, created_at FROM Users WHERE user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

/* =========================
   UPDATE USERNAME
========================= */
if (isset($_POST['update_username'])) {
    $username = trim($_POST['username']);

    if (empty($username)) {
        $message = "Username cannot be empty.";
    } else {
        // Check if username already exists (excluding current user)
        $stmt = $conn->prepare("
            SELECT user_id 
            FROM Users 
            WHERE username = ? 
              AND user_id != ?
        ");
        $stmt->bind_param("si", $username, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $message = "Username already exists.";
        } else {
            // Update username
            $stmt = $conn->prepare("
                UPDATE Users 
                SET username = ? 
                WHERE user_id = ?
            ");
            $stmt->bind_param("si", $username, $user_id);
            $stmt->execute();

            $message = "Username updated successfully!";
            
            // Refresh displayed data
            $user['username'] = $username;
        }
    }
}

/* =========================
   UPDATE PASSWORD
========================= */
if (isset($_POST['update_password'])) {
    $current_password = trim($_POST['current_password']);
    $new_password     = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Get current password hash from DB
    $stmt = $conn->prepare("
        SELECT password_hash 
        FROM Users 
        WHERE user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row    = $result->fetch_assoc();

    // Validate current password
    if (!password_verify($current_password, $row['password_hash'])) {
        $message = "Current password is incorrect.";
    } 
    // Validate new password confirmation
    elseif ($new_password !== $confirm_password) {
        $message = "New password and confirmation password do not match.";
    } 
    // Validate password length
    elseif (strlen($new_password) < 6) {
        $message = "Password must be at least 6 characters long.";
    } 
    else {
        // Hash new password
        $new_hash = password_hash($new_password, PASSWORD_DEFAULT);

        // Update password in DB
        $stmt = $conn->prepare("
            UPDATE Users 
            SET password_hash = ? 
            WHERE user_id = ?
        ");
        $stmt->bind_param("si", $new_hash, $user_id);
        $stmt->execute();

        $message = "Password updated successfully!";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <link rel="stylesheet" href="css/submit.css">
    <style>
        .submitform {
            max-width: 900px;
            margin: 30px auto;
            margin-top: 100px;
            display: grid;
            gap: 15px;
        }
        h1 { color: #fff; }
        .profile-card {
            background: #111;
            color: #fff;
            padding: 20px;
            border-radius: 10px;
        }
        .settings-box {
            background: #111;
            padding: 15px;
            border-radius: 10px;
            color: #fff;
            position: relative;
        }
        .toggle-btn {
            background: #2c2c2c;
            border: none;
            padding: 8px 12px;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
            margin-bottom: 10px;
            display: inline-block;
        }
        .form-box {
            display: none;
            margin-top: 10px;
            background: #1b1b1b;
            padding: 12px;
            border-radius: 8px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            border-radius: 5px;
            border: none;
        }
        .save-btn {
            margin-top: 10px;
            background: #8c6500;
            color: #fff;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }


    </style>
    <script>
        function toggleBox(id) {
            var box = document.getElementById(id);
            box.style.display = (box.style.display === "block") ? "none" : "block";
        }
    </script>
</head>
<body>
<div class="submitform">
    <h1>My Profile</h1>

    <?php if (!empty($message)): ?>
        <div class="notif-banner">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- PROFILE -->
    <div class="profile-card">
        <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        <p><strong>Joined:</strong> <?php echo $user['created_at']; ?></p>
    </div>

    <!-- SETTINGS -->
    <div class="settings-box">
        <h3>Account Settings</h3>

        <button class="toggle-btn" onclick="toggleBox('usernameBox')">
            Change Username
        </button>

        <button class="toggle-btn" onclick="toggleBox('passBox')">
            Change Password
        </button>

        <div id="usernameBox" class="form-box">
            <form method="POST">
                <input type="text"
                    name="username"
                    value="<?php echo htmlspecialchars($user['username']); ?>"
                    placeholder="Enter new username"
                    required>
                <button class="save-btn" type="reset">Cancel</button>   
                <button class="save-btn" name="update_username">Save Username</button>
            </form>
        </div>
  <div id="passBox" class="form-box">
    <form method="POST">

        <span id="togglePassword" style="cursor:pointer;font-size:18px;">
            👁 Show Passwords
        </span>

        <input type="password"
               class="password-field"
               name="current_password"
               placeholder="Current Password"
               required>

        <input type="password"
               class="password-field"
               name="new_password"
               placeholder="New Password"
               required>

        <input type="password"
               class="password-field"
               name="confirm_password"
               placeholder="Confirm New Password"
               required>
        <button class="save-btn" type="reset"
                name="cancel">
            Cancel
        </button>
        <button class="save-btn"
                name="update_password">
            Save Password
        </button>

    </form>
</div>

        <script>
document.getElementById('togglePassword').addEventListener('click', function () {

    const fields = document.querySelectorAll('.password-field');

    fields.forEach(field => {
        field.type = field.type === 'password' ? 'text' : 'password';
    });

    this.textContent =
        fields[0].type === 'password'
            ? '👁 Show Passwords'
            : '🙈 Hide Passwords';
});
</script>

    </div>
</div>
</body>
</html>
