<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$report_id = $_POST['report_id'];
$claim_details = trim($_POST['claim_details']);

// Insert claim request
$sql = "INSERT INTO Claims (report_id, user_id, claim_details, status, created_at) 
        VALUES (?, ?, ?, 'Pending', NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $report_id, $user_id, $claim_details);

if ($stmt->execute()) {
    // Notify admin
    $notif_sql = "INSERT INTO Notifications (user_id, message, created_at) 
                  VALUES (?, ?, NOW())";
    $notif_stmt = $conn->prepare($notif_sql);
    $admin_id = 1;
    $message = "New claim request for Report ID: $report_id";
    $notif_stmt->bind_param("is", $admin_id, $message);
    $notif_stmt->execute();

    echo "<p style='color: white; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);'>Your claim has been submitted. The admin will review it.</p>";
} else {
    echo "Error submitting claim.";
}
?>

