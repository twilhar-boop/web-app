<?php
session_start();
include 'db.php';

// from user to CONTACT ADMIN 

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle new message submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $report_id = !empty($_POST['report_id']) ? $_POST['report_id'] : null;
    $content   = trim($_POST['content']);

    // Always send to admin (assuming admin_id = 1 or fetched from DB)
    $admin_id = 1; // Replace with actual admin user_id from your Users table

    $sql_insert = "INSERT INTO Messages (sender_id, receiver_id, report_id, content, sent_at) 
                   VALUES (?, ?, ?, ?, NOW())";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("iiis", $user_id, $admin_id, $report_id, $content);

    if ($stmt_insert->execute()) {
        echo "<p class='success'>Message sent to admin successfully!</p>";
    } else {
        echo "<p class='error'>Error sending message. Please try again.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>REQUEST MESSAGE</title>
    <link rel="stylesheet" href="css/messages.css">
</head>
<body>

<div class="form">
    <a href="dashboard.php"> Back </a><br><br><br>
    <h2>Send a note to the Admin</h2>
    Report any problem or issue, your feedback will help us improve.<br><br><br><br><br>
    <form method="POST" class="send-form">
        <p>
        <label for="report_id">Report ID (optional):</label><br>
        <input type="number" name="report_id"> <br></p>

        <p><label for="content">Message:</label><br>
        <textarea name="content" required></textarea></p><br><br><br><br><br>

        <button type="submit">Send Message</button>
    </form>
    </div>
</body>
</html>
