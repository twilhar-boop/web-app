<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];


// Fetch username from database
$stmt = $conn->prepare("SELECT username FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$username = $user['username'];


// Helper function for user-friendly date and time
function formatDateTime($datetime) {
    $time = strtotime($datetime);
    return date("F j, Y g:i A", $time);
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="css/userdash.css">
</head>
<body>


    <div class="both">
        <div class="imgcontainer">
            <h2 class="greets"><br><br>Hello, <?php echo htmlspecialchars($username); ?>! Great to have you here. <br><br></h2>
            <img src="css/logo.png" class="logo">
            <img src="css/itemsbanner.png">
        </div>
        <div class="content">
            <h2>Reunite with the things that belongs to you</h2>
            <p>Select an option to get started.</p>
            <div class="btn2">
                <button onclick="window.location.href='submit_report.php'" class="btn">File a Missing or Found Item </button>
                <button onclick="window.location.href='view_reports.php'" class="btn">Looking for your Belongings?</button>
            </div>
            <p class="credit">© 2026 Lost & Found System | Designed by Wilhar F. Tagud</p>
        </div>
    </div>

</body>
</html>
