<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Guard clause for missing ID
if (!isset($_GET['id'])) {
    die("No report ID provided.");
}

$current_id = intval($_GET['id']);
$statusMsg = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $match_id = intval($_POST['match_id']);

    // Update both reports as matched
    $sql_update = "UPDATE Reports SET status='Matched' WHERE report_id IN (?, ?)";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ii", $current_id, $match_id);
    $stmt_update->execute();

    // Fetch both users
    $sql_users = "SELECT report_id, user_id FROM Reports WHERE report_id IN (?, ?)";
    $stmt_users = $conn->prepare($sql_users);
    $stmt_users->bind_param("ii", $current_id, $match_id);
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();

    // Notify both users
    $sql_notify = "INSERT INTO Notifications (user_id, report_id, message) VALUES (?, ?, ?)";
    $stmt_notify = $conn->prepare($sql_notify);

    while ($row = $result_users->fetch_assoc()) {
        $msg = "Your item report #{$row['report_id']} has been matched!";
        $stmt_notify->bind_param("iis", $row['user_id'], $row['report_id'], $msg);
        $stmt_notify->execute();
    }

    $statusMsg = "Reports $current_id and $match_id matched successfully!";
}

// Fetch current report
$sql_current = "SELECT r.report_id, u.username, i.category, i.description, i.photo_url, r.report_type 
                FROM Reports r
                JOIN Users u ON r.user_id = u.user_id
                JOIN Items i ON r.item_id = i.item_id
                WHERE r.report_id=?";
$stmt_current = $conn->prepare($sql_current);
$stmt_current->bind_param("i", $current_id);
$stmt_current->execute();
$current_report = $stmt_current->get_result()->fetch_assoc();

if (!$current_report) {
    die("Report not found.");
}
//IF STATUS = MISSING - LIST OF FOUND REPORTS SHOWS
//IF STATUS = FOUND - LIST OF MISSING REPORTS SHOWS

// Fetch current report
$sql_current = "SELECT r.report_id, r.user_id, u.username, i.category, i.description, i.photo_url, r.report_type 
                FROM Reports r
                JOIN Users u ON r.user_id = u.user_id
                JOIN Items i ON r.item_id = i.item_id
                WHERE r.report_id=?";
$stmt_current = $conn->prepare($sql_current);
$stmt_current->bind_param("i", $current_id);
$stmt_current->execute();
$current_report = $stmt_current->get_result()->fetch_assoc();

if (!$current_report) {
    die("Report not found.");
}

$current_user_id = $current_report['user_id'];

// Determine opposite type for matching
$opposite_type = ($current_report['report_type'] === 'missing') ? 'found' : 'missing';

// ✅ Fetch other users’ reports only
$sql_other = "SELECT r.report_id, u.username, i.category, i.description, i.photo_url
              FROM Reports r
              JOIN Users u ON r.user_id = u.user_id
              JOIN Items i ON r.item_id = i.item_id
              WHERE r.report_id != ? 
                AND r.user_id != ? 
                AND r.status='Unmatched' 
                AND r.report_type=?";
$stmt_other = $conn->prepare($sql_other);
$stmt_other->bind_param("iis", $current_id, $current_user_id, $opposite_type);
$stmt_other->execute();
$other_reports = $stmt_other->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Match Items</title>
    <link rel="stylesheet" href="../css/adminpage.css">
    <style>
       /* Match Items container */
.modport {
    background: #fffaf5; /* light cream */
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(75,46,46,0.2);
    padding: 25px;
    max-width: 700px;
    margin: 20px auto;
    font-size: 0.95em;
    color: #3e2c2c; /* espresso */
}

/* Heading */
.modport h2 {
    margin-top: 0;
    font-size: 1.4em;
    color: #4b2e2e;
    border-bottom: 2px solid #d9a066; /* caramel accent */
    padding-bottom: 8px;
}

/* Labels and text */
.modport p {
    margin: 8px 0;
    line-height: 1.4;
}

/* Select dropdown */
.modport select {
    width: 100%;
    padding: 10px;
    border: 1px solid #d9a066;
    border-radius: 6px;
    background: #fff;
    font-size: 0.95em;
    color: #3e2c2c;
    margin-top: 8px;
    transition: border-color 0.3s, box-shadow 0.3s;
}

.modport select:focus {
    outline: none;
    border-color: #6b3f3f;
    box-shadow: 0 0 6px rgba(107,63,63,0.4);
}

/* Buttons */
.modport button {
    margin-top: 15px;
    padding: 10px 18px;
    border: none;
    border-radius: 6px;
    background: #d9a066; /* caramel */
    color: #fff;
    font-size: 0.95em;
    font-weight: 600;
    cursor: pointer;
    transition: background 0.3s, transform 0.2s;
}

.modport button:hover {
    background: #6b3f3f; /* mocha hover */
    transform: translateY(-2px);
}

/* Thumbnail images */
.thumb {
    max-width: 120px;
    max-height: 120px;
    border-radius: 6px;
    border: 1px solid #d9a066;
    object-fit: cover;
    cursor: pointer;
    transition: transform 0.2s ease, border-color 0.2s ease;
}

.thumb:hover {
    transform: scale(1.1);
    border-color: #6b3f3f;
}

    </style>
</head>
<body>
<div class="container">

    <div class="modport">
        <h2>Match Report #<?php echo $current_report['report_id']; ?></h2>
        <p><b>User:</b> <?php echo $current_report['username']; ?></p>
        <p><b>Category:</b> <?php echo $current_report['category']; ?></p>
        <p><b>Description:</b> <?php echo $current_report['description']; ?></p>
        <p><b>Photo:</b>
            <?php if (!empty($current_report['photo_url'])) { ?>
                <img src="<?php echo $current_report['photo_url']; ?>" alt="Item photo" class="thumb">
            <?php } else { ?>
                No photo
            <?php } ?>
        </p>

        <?php if ($statusMsg) { ?>
            <p style="color: green; font-weight: bold;"><?php echo $statusMsg; ?></p>
        <?php } ?>

        <form method="POST">
            <label for="match_id">Select report to match:</label>
            <select name="match_id" id="match_id" required>
                <?php if ($other_reports && $other_reports->num_rows > 0) {
                    while ($row = $other_reports->fetch_assoc()) { ?>
                        <option value="<?php echo $row['report_id']; ?>">
                            ID <?php echo $row['report_id']; ?> - <?php echo $row['category']; ?> 
                            (<?php echo $row['description']; ?>) by <?php echo $row['username']; ?>
                            <?php if (!empty($row['photo_url'])) { ?>
                                <img src="../<?php echo htmlspecialchars($row['photo_url']); ?>" 
                                alt="Item photo" class="thumb">
                            <?php } else { ?>
                                No photo
                            <?php } ?>
                        </option>
                <?php } } else { ?>
                    <option disabled>No other reports available</option>
                <?php } ?>
            </select>
            <br><br>
            <button type="submit">Confirm Match</button>
        </form>
    </div>
</div>
</body>
</html>
