<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];


// Fetch username from database
$stmt = $conn->prepare("SELECT username FROM Users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$username = $user['username'];


// Helper function for friendly time display
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;

    if ($diff < 60) return $diff . " seconds ago";
    elseif ($diff < 3600) return floor($diff/60) . " minutes ago";
    elseif ($diff < 86400) return floor($diff/3600) . " hours ago";
    else return floor($diff/86400) . " days ago";
}

// Fetch notifications (no status column anymore)
$sql = "SELECT notification_id, message, created_at 
        FROM Notifications 
        WHERE user_id=? 
        ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Count total notifications
$sql_count = "SELECT COUNT(*) AS notif_count 
              FROM Notifications 
              WHERE user_id=?";
$stmt_count = $conn->prepare($sql_count);
$stmt_count->bind_param("i", $user_id);
$stmt_count->execute();
$count_result = $stmt_count->get_result();
$count_row = $count_result->fetch_assoc();
$notif_count = $count_row['notif_count'];
?>


<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" type="text/css" href="../css/adminpage.css">
</head>
<body>
    <div class="admindash">
        <h2 class="MD">Moderate Reports</h2> 
        <a href="reports_dashboard.php" target="myFrame">Dashboard</a> 
        <a href="add_report.php" target="myFrame">File Report</a> 
        <a href="moderate_reports.php" target="myFrame">Moderate Reports</a> 
        <a href="matched_reports.php" target="myFrame">Matched Reports</a>
        <a href="approve_claims.php" target="myFrame">Approve Claims</a>   
        <a href="user_messages.php" target="myFrame">Email</a>
        
        <a href="report_history.php" target="myFrame">Report History</a>   
        <br><br><br><br><br><br><br><br><br><br><br><br>
        <a href="../login.php">Logout</a>

        <?php if (!empty($_SESSION['statusMsg'])) { ?>
            <p class="popup"><?php echo $_SESSION['statusMsg']; ?></p>
            <?php unset($_SESSION['statusMsg']); ?>
        <?php } ?>
    </div>

    <div class="main-container">
        <iframe name="myFrame" src="moderate_reports.php"></iframe>
    </div>

    <script>
    document.getElementById("notif_toggle").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.add("open");
    });
    document.getElementById("close_overlay").addEventListener("click", function() {
        document.getElementById("notif_overlay").classList.remove("open");
    });
    </script>
</body>
</html>
