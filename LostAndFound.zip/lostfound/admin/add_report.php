<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];

$statusMsg = ""; 



// Handle report submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category    = $_POST['category'];
    $description = $_POST['description'];
    $location    = $_POST['location'];
    $status      = $_POST['status']; // missing/found
    $photo_url   = null;

    // Handle photo upload if provided
    if (!empty($_FILES['photo']['name'])) {
        $target_dir  = "../uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $filename     = time() . "_" . basename($_FILES["photo"]["name"]);
        $target_file  = $target_dir . $filename;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $allowed_types = ["jpg", "jpeg", "png", "gif"];
        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                $photo_url = $target_file;
            }
        }
    }

    // Insert item
    $sql_item = "INSERT INTO Items (category, description, location, status, photo_url) VALUES (?, ?, ?, ?, ?)";
    $stmt_item = $conn->prepare($sql_item);
    $stmt_item->bind_param("sssss", $category, $description, $location, $status, $photo_url);
    $stmt_item->execute();
    $item_id = $stmt_item->insert_id;

    // Insert report
    $sql_report = "INSERT INTO Reports (user_id, item_id, report_type) VALUES (?, ?, ?)";
    $stmt_report = $conn->prepare($sql_report);
    $stmt_report->bind_param("iis", $user_id, $item_id, $status);
    $stmt_report->execute();

    $statusMsg = "Report submitted successfully!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Lost and Found</title>
    <link rel="stylesheet" href="../css/add_report.css">
</head>
<body>


<div class="container">
    

<div class="subflex">
    <div class="submitform">
        <form method="POST" enctype="multipart/form-data">
    <?php if ($statusMsg) { ?>
        <p class="popup"><?php echo $statusMsg; ?></p> <!-- Display success message when you submit the form -->
    <?php } ?>            
            <h1> Report an Item </h1>
            <hr>
            <table >
                <tr>
                    <td><label for="status">Status:</label></td>
                    <td><label for="photo">Photo:</label></td>
                </tr>
                <tr>
                    <td>
                        <select name="status" class="sub">
                            <option value="missing">Missing</option>
                            <option value="found">Found</option>
                        </select>                      
                    </td>
                    <td><input type="file" name="photo" placeholder="Choose a photo" accept="image/*" required></td>
                </tr>
                <tr>
                    <td><label for="category">Category (e.g. Electronics, Cash, Keys, Card):</label></td>
                    <td><label for="location">Location Lost/Found (Specify):</label></td>                
                </tr>
                <tr>
                    <td><input type="text" name="category" placeholder="item type or name" required></td>
                    <td><input type="text" name="location" placeholder="location where item was lost or found" required></td>                   
                </tr>
                <tr>
                    <td><label for="description">Description:</label></td>      
                </tr>
                <tr>
                    <td><textarea name="description" placeholder="Add name of owner then item description" required></textarea></td>
                </tr>
            </table><br><br>
            <div class="btns">
            <button type="reset">Cancel</button>
            <button type="submit">Submit Report</button>
            </div>
        </form>
    </div>
</div>

    </div>


    <script>
  // Wait until the page loads
  window.addEventListener("DOMContentLoaded", function() {
    const popup = document.querySelector(".popup");
    if (popup) {
      // Auto-hide after 3 seconds
      setTimeout(() => {
        popup.style.opacity = "0";
        popup.style.top = "-100px";
        popup.style.transition = "all 0.5s ease";
        // Remove from DOM after fade-out
        setTimeout(() => popup.remove(), 500);
      }, 3000);
    }
  });
</script>

</body>
</html>
