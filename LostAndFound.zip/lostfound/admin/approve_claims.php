<?php
session_start();
include '../db.php';

// Only allow admins
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Handle approve/reject actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $claim_id = intval($_GET['id']);
    $action = $_GET['action']; // "approve" or "reject"

    if ($action === 'approve') {
        $newStatus = 'Approved';
    } elseif ($action === 'reject') {
        $newStatus = 'Rejected';
    }

    $sql_update = "UPDATE Claims SET status=? WHERE claim_id=?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("si", $newStatus, $claim_id);
    $stmt_update->execute();

    // Notify user
    $sql_user = "SELECT user_id, report_id FROM Claims WHERE claim_id=?";
    $stmt_user = $conn->prepare($sql_user);
    $stmt_user->bind_param("i", $claim_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    if ($row = $result_user->fetch_assoc()) {
        $user_id = $row['user_id'];
        $report_id = $row['report_id'];
        $msg = "Your claim for Report #$report_id has been $newStatus by admin.";
        $sql_notify = "INSERT INTO Notifications (user_id, message, created_at) VALUES (?, ?, NOW())";
        $stmt_notify = $conn->prepare($sql_notify);
        $stmt_notify->bind_param("is", $user_id, $msg);
        $stmt_notify->execute();
    }

    header("Location: approve_claims.php");
    exit();
}

// Fetch all claims
$sql_claims = "SELECT c.claim_id, c.report_id, c.claim_details, c.status, c.created_at,
                      u.username, i.category, i.description
               FROM Claims c
               JOIN Users u ON c.user_id = u.user_id
               JOIN Reports r ON c.report_id = r.report_id
               JOIN Items i ON r.item_id = i.item_id
               ORDER BY c.created_at DESC";
$result_claims = $conn->query($sql_claims);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Approve Claims</title>
    <link rel="stylesheet" href="css/adminpage.css">
    <style>
       
        body {
            font-family: "Segoe UI", sans-serif;
            background-color: #f5f2ed; 
            margin: 0;
            padding: 0;
            color: #3e2c23; 
        }

        .container {
            width: 95%;
            height: 100%;
            padding: 20px;
        }

        .modport {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(62, 44, 35, 0.2);
            padding: 20px;
            animation: fadeIn 0.6s ease;
        }

        h2 {
            color: #5c4033;
            border-left: 6px solid #c19a6b; 
            padding-left: 10px;
            margin-bottom: 20px;
        }

        table.modtab {
            width: 100%;             
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            table-layout: fixed;
        }

        table.modtab th {
            background: #3e2c23; 
            color: #f5f2ed;    
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }

        table.modtab td {
            padding: 12px;
            border-bottom: 1px solid #e0d6cf;
            word-wrap: break-word;
        }

        table.modtab tr:hover {
            background-color: #f0e6dd; 
            transition: background 0.3s ease;
        }

        a.action {
            text-decoration: none;
            color: #fff;
            background-color: #5c4033;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 6px;
            transition: all 0.3s ease;
            margin: 2px 4px;
            display: inline-block;
        }

        a.action:hover {
            background-color: #c19a6b; 
            color: #fff;
        }

        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(10px);}
            to {opacity: 1; transform: translateY(0);}
        }

        
    </style>
</head>
<body>
<div class="container">
    <div class="modport">
        <h2>Approve Claims</h2>
        <table class="modtab">
            <tr>
                <th>Claim ID</th>
                <th>User</th>
                <th>Report ID</th>
                <th>Category</th>
                <th>Description</th>
                <th>Claim Details</th>
                <th>Status</th>
                <th>Submitted At</th>
                <th>Actions</th>
            </tr>
            <?php if ($result_claims && $result_claims->num_rows > 0) {
                while ($row = $result_claims->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['claim_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><?php echo $row['report_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['category']); ?></td>
                        <td><?php echo htmlspecialchars($row['description']); ?></td>
                        <td><?php echo htmlspecialchars($row['claim_details']); ?></td>
                        <td>
                            <?php 
                            $status = strtolower($row['status']); 
                            if ($status === 'pending') {
                                echo "<span >Pending</span>";
                            } elseif ($status === 'approve' || $status === 'approved') {
                                echo "<span >Approved</span>";
                            } elseif ($status === 'reject' || $status === 'rejected') {
                                echo "<span >Rejected</span>";
                            } else {
                                echo ucfirst($row['status']);
                            }
                            ?>
                        </td>
                        <td><?php echo date("F j, Y g:i A", strtotime($row['created_at'])); ?></td>
                        <td>
                            <?php if ($row['status'] === 'Pending') { ?>
                                <a class="action" href="approve_claims.php?action=approve&id=<?php echo $row['claim_id']; ?>">Approve</a>
                                <a class="action" href="approve_claims.php?action=reject&id=<?php echo $row['claim_id']; ?>">Reject</a>
                            <?php } else { ?>
                                <?php echo ucfirst($row['status']); ?>
                            <?php } ?>
                        </td>
                    </tr>
            <?php } } else { ?>
                <tr><td colspan="9">No claims submitted yet.</td></tr>
            <?php } ?>
        </table>
    </div>
</div>
</body>
</html>
