<?php
session_start();
include '../db.php';

// Check if logged in and role is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

$admin_id = $_SESSION['user_id']; // set admin ID

if (isset($_GET['report_id'])) {
    $report_id = intval($_GET['report_id']);
    // 1. Fetch report details
    $reportQuery = mysqli_query($conn, "SELECT category, description, type FROM Reports WHERE report_id=$report_id");
    if ($reportQuery && mysqli_num_rows($reportQuery) > 0) {
        $report = mysqli_fetch_assoc($reportQuery);

        // 2. Insert snapshot into ReportHistory
        $insertHistory = "INSERT INTO ReportHistory 
            (report_ID, ACTION, performed_by, timestamp, category, description, type)
            VALUES ($report_id, 'delete', $admin_id, NOW(), 
                    '".mysqli_real_escape_string($conn, $report['category'])."', 
                    '".mysqli_real_escape_string($conn, $report['description'])."', 
                    '".$report['type']."')";
        mysqli_query($conn, $insertHistory);

        // 3. Delete the report
        mysqli_query($conn, "DELETE FROM Reports WHERE report_id=$report_id");
    }
}

// Fetch history logs for display
$result = mysqli_query($conn, "SELECT h.*, u.username AS admin_name 
                               FROM ReportHistory h 
                               LEFT JOIN users u ON h.performed_by = u.user_id 
                               ORDER BY h.timestamp DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Report History</title>
    <link rel="stylesheet" type="text/css" href="css/adminpage.css">
    <style>
        /* Coffee Modern Theme */
        body {
            font-family: "Segoe UI", sans-serif;
            background-color: #f5f2ed; /* latte cream */
            margin: 0;
            padding: 0;
            color: #3e2c23; /* espresso brown */
        }

        .container {
            width: 95%;
            height: 100%;
            padding: 20px;
        }

        .modport {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(62, 44, 35, 0.2);
            padding: 20px;
            animation: fadeIn 0.6s ease;
        }

        h2.allrep {
            color: #5c4033; /* mocha */
            border-left: 6px solid #c19a6b; /* caramel accent */
            padding-left: 10px;
            margin-bottom: 20px;
        }

        table.modtab {
            width: 100%;              /* Full iframe width */
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            table-layout: fixed;
        }

        table.modtab th {
            background: #3e2c23; /* espresso */
            color: #f5f2ed;      /* cream */
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }

        table.modtab td {
            padding: 12px;
            border-bottom: 1px solid #e0d6cf;
            word-wrap: break-word;
        }

        table.modtab tr:hover {
            background-color: #f0e6dd; /* light latte hover */
            transition: background 0.3s ease;
        }

        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(10px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="modport">
        <h2 class="allrep">History Logs</h2>
        <table class="modtab">
    <tr>
        <th>History ID</th>
        <th>Report ID</th>
        <th>Action</th>
        <th>Performed By ID</th>
        <th>Username</th>
        <th>Category</th>
        <th>Description</th>
        <th>Type</th>
        <th>Timestamp</th>
    </tr>

    <?php if(mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['history_id']; ?></td>
            <td><?php echo $row['report_ID']; ?></td>
            <td><?php echo ucfirst($row['ACTION']); ?></td>
            <td><?php echo $row['performed_by']; ?></td>
            <td><?php echo htmlspecialchars($row['admin_name'] ?? 'Unknown'); ?></td>
            <td><?php echo htmlspecialchars($row['category']); ?></td>
            <td><?php echo htmlspecialchars($row['description']); ?></td>
            <td><?php echo htmlspecialchars($row['type']); ?></td>
            <td><?php echo date("F j, Y g:i A", strtotime($row['timestamp'])); ?></td>
        </tr>
        <?php } ?>
    <?php else: ?>
        <tr>
            <td colspan="9" style="text-align:center;">
                No history records found.
            </td>
        </tr>
    <?php endif; ?>
</table>
    </div>
</div>
</body>
</html>
