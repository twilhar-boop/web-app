<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Fetch counts
$totalReports = $conn->query("SELECT COUNT(*) AS c FROM Reports")->fetch_assoc()['c'];
$totalUsers   = $conn->query("SELECT COUNT(*) AS c FROM Users")->fetch_assoc()['c'];
$totalClaims  = $conn->query("SELECT COUNT(*) AS c FROM Claims")->fetch_assoc()['c'];

// Recent reports
$recentReports = $conn->query("SELECT report_id, report_type, status, created_at 
                               FROM Reports ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: "Segoe UI", sans-serif;
            background-color: #f5f2ed; 
            margin: 0;
            padding: 0;
            color: #3e2c23;
        }
        .container {
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #5c4033;
            margin-bottom: 30px;
        }
        .cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .card {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(62, 44, 35, 0.2);
            animation: fadeIn 0.6s ease;
        }
        .card h2 {
            margin: 0;
            font-size: 2em;
            color: #5c4033;
        }
        .card p {
            margin: 5px 0 0;
            font-size: 0.9em;
            color: #7a5c4a;
        }
        h2.section-title {
            color: #5c4033; 
            border-left: 6px solid #c19a6b; 
            padding-left: 10px;
            margin-bottom: 20px;
        }
        table.reports {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            table-layout: fixed;
        }
        table.reports th, 
        table.reports td {
            padding: 12px;
            border-bottom: 1px solid #e0d6cf;
            word-wrap: break-word;
        }
        table.reports th {
            background: #3e2c23; 
            color: #f5f2ed; 
            font-weight: 600;
            text-align: left;
        }
        table.reports tr:hover {
            background-color: #f0e6dd;
            transition: background 0.3s ease;
        }
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(10px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Admin Dashboard</h1>

    <div class="cards">
        <div class="card"><h2><?php echo $totalReports; ?></h2><p>Total Reports</p></div>
        <div class="card"><h2><?php echo $totalUsers; ?></h2><p>Total Users</p></div>
        <div class="card"><h2><?php echo $totalClaims; ?></h2><p>Total Claims</p></div>
    </div>

    <h2 class="section-title">Recent Reports</h2>
    <div class="subflex">
        <table class="reports">
            <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
            <?php while($r = $recentReports->fetch_assoc()): ?>
            <tr>
                <td><?php echo $r['report_id']; ?></td>
                <td><?php echo ucfirst($r['report_type']); ?></td>
                <td><?php echo $r['status']; ?></td>
                <td><?php echo date("F j, Y g:i A", strtotime($r['created_at'])); ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
</body>
</html>
