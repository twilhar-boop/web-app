<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Handle unmatch action
if (isset($_GET['action']) && $_GET['action'] === 'unmatch' && isset($_GET['id1']) && isset($_GET['id2'])) {
    $id1 = intval($_GET['id1']);
    $id2 = intval($_GET['id2']);

    $sql_unmatch = "UPDATE Reports SET status='Unmatched' WHERE report_id IN (?, ?)";
    $stmt_unmatch = $conn->prepare($sql_unmatch);
    $stmt_unmatch->bind_param("ii", $id1, $id2);
    $stmt_unmatch->execute();

    header("Location: matched_reports.php");
    exit();
}

// Handle claim action
if (isset($_GET['action']) && $_GET['action'] === 'claim' && isset($_GET['id1']) && isset($_GET['id2'])) {
    $id1 = intval($_GET['id1']);
    $id2 = intval($_GET['id2']);

    $sql_claim = "UPDATE Reports SET status='Claimed' WHERE report_id IN (?, ?)";
    $stmt_claim = $conn->prepare($sql_claim);
    $stmt_claim->bind_param("ii", $id1, $id2);
    $stmt_claim->execute();

    // Insert into matchedreports table
    $sql_insert = "INSERT INTO matchedreports (id1, id2) VALUES (?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("ii", $id1, $id2);
    $stmt_insert->execute();

    header("Location: matched_reports.php");
    exit();
}

// Fetch all matched reports
$sql_matches = "SELECT r.report_id, u.username, i.category, i.description, r.report_type, r.created_at
                FROM Reports r
                JOIN Users u ON r.user_id = u.user_id
                JOIN Items i ON r.item_id = i.item_id
                WHERE r.status='Matched'
                ORDER BY r.created_at DESC";
$matches_result = $conn->query($sql_matches);

$sql_claims = "SELECT r.report_id, u.username, i.category, i.description, r.report_type, r.created_at
                FROM Reports r
                JOIN Users u ON r.user_id = u.user_id
                JOIN Items i ON r.item_id = i.item_id
                WHERE r.status='Claimed'
                ORDER BY r.created_at DESC";
$claim_details = $conn->query($sql_claims);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Matched Reports</title>
    <link rel="stylesheet" type="text/css" href="../css/adminpage.css">
    <style>
       
        body {
            font-family: "Segoe UI", sans-serif;
            background-color: #f5f2ed; 
            margin: 0;
            padding: 0;
            color: #3e2c23;
        }
        table.edrep {
            width: 100%;              
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            table-layout: fixed;     
        }

        table.edrep th, 
        table.edrep td {
            padding: 12px;
            border-bottom: 1px solid #e0d6cf;
            word-wrap: break-word;    
        }

        .subflex {
            width: 100%;             
            overflow-x: auto;         
        }


        .container {
            padding: 20px;
        }

        .modport {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(62, 44, 35, 0.2);
            padding: 20px;
            animation: fadeIn 0.6s ease;
        }

        h2.allrep {
            color: #5c4033; 
            border-left: 6px solid #c19a6b; 
            padding-left: 10px;
            margin-bottom: 20px;
        }

        table.edrep {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
        }

        table.edrep th {
            background: #3e2c23; 
            color: #f5f2ed; 
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }

        table.edrep td {
            padding: 12px;
            border-bottom: 1px solid #e0d6cf;
        }

        table.edrep tr:hover {
            background-color: #f0e6dd;
            transition: background 0.3s ease;
        }

        a {
            text-decoration: none;
            color: #5c4033;
            font-weight: 600;
            padding: 6px 10px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

       a:hover {
        color: #c19a6b;
       }

        
        .subflex {
            overflow-x: auto;
        }

        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(10px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="modport">
        <div class="subflex">
            <h2 class="allrep">Matched Reports</h2>
            <table class="edrep">
                <tr>
                    <th>Report IDs</th>
                    <th>Users</th>
                    <th>Categories</th>
                    <th>Descriptions</th>
                    <th>Types</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
                <?php 
                if ($matches_result && $matches_result->num_rows > 0) {
                    $pair_reports = [];
                    while ($match = $matches_result->fetch_assoc()) {
                        $pair_reports[] = $match;
                        if (count($pair_reports) === 2) {
                            echo "<tr>
                                    <td>{$pair_reports[0]['report_id']} & {$pair_reports[1]['report_id']}</td>
                                    <td>{$pair_reports[0]['username']} & {$pair_reports[1]['username']}</td>
                                    <td>{$pair_reports[0]['category']} & {$pair_reports[1]['category']}</td>
                                    <td>{$pair_reports[0]['description']} & {$pair_reports[1]['description']}</td>
                                    <td>{$pair_reports[0]['report_type']} & {$pair_reports[1]['report_type']}</td>
                                    <td>"
                                        .date("F j, Y g:i A", strtotime($pair_reports[0]['created_at']))." & "
                                        .date("F j, Y g:i A", strtotime($pair_reports[1]['created_at']))."
                                    </td>
                                    <td>
                                        <a href='?action=unmatch&id1={$pair_reports[0]['report_id']}&id2={$pair_reports[1]['report_id']}'>Unmatch</a> | 
                                        <a href='?action=claim&id1={$pair_reports[0]['report_id']}&id2={$pair_reports[1]['report_id']}'>Claim</a>
                                    </td>
                                  </tr>";
                            $pair_reports = [];
                        }
                    }
                } else {
                    echo "<tr><td colspan='7'>No matched reports yet.</td></tr>";
                }
                ?>
            </table>
        </div>     
    </div>

    <br>
     <div class="modport">
        <div class="subflex">
            <h2 class="allrep">Claimed Items</h2>
            <table class="edrep">
                <tr>
                    <th>Report IDs</th>
                    <th>Users</th>
                    <th>Categories</th>
                    <th>Descriptions</th>
                    <th>Types</th>
                    <th>Created At</th>
                    
                </tr>
                <?php 
                if ($claim_details && $claim_details->num_rows > 0) {
                    $pair_reports = [];
                    while ($match = $claim_details->fetch_assoc()) {
                        $pair_reports[] = $match;
                        if (count($pair_reports) === 2) {
                            echo "<tr>
                                    <td>{$pair_reports[0]['report_id']} & {$pair_reports[1]['report_id']}</td>
                                    <td>{$pair_reports[0]['username']} & {$pair_reports[1]['username']}</td>
                                    <td>{$pair_reports[0]['category']} & {$pair_reports[1]['category']}</td>
                                    <td>{$pair_reports[0]['description']} & {$pair_reports[1]['description']}</td>
                                    <td>{$pair_reports[0]['report_type']} & {$pair_reports[1]['report_type']}</td>
                                    <td>"
                                        .date("F j, Y g:i A", strtotime($pair_reports[0]['created_at']))." & "
                                        .date("F j, Y g:i A", strtotime($pair_reports[1]['created_at']))."
                                    </td>
                                    
                                  </tr>";
                            $pair_reports = [];
                        }
                    }
                } else {
                    echo "<tr><td colspan='7'>No matched reports yet.</td></tr>";
                }
                ?>
            </table>
        </div>
        
        
    </div>
</div>
</body>
</html>
