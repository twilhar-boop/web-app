<?php
session_start();
include '../db.php';

// Check if logged in and role is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$admin_id = 1; 

// Handle reply submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_message'])) {
    $user_id = intval($_POST['user_id']);
    $reply_message = trim($_POST['reply_message']);

    if (!empty($reply_message)) {
        $sql_reply = "INSERT INTO Notifications (user_id, message) VALUES (?, ?)";
        $stmt_reply = $conn->prepare($sql_reply);
        $stmt_reply->bind_param("is", $user_id, $reply_message);
        $stmt_reply->execute();
    }
}

// Fetch user messages sent to admin
$sql_messages = "SELECT m.message_id, u.user_id, u.username, u.email, m.content, m.sent_at 
                 FROM Messages m
                 JOIN Users u ON m.sender_id = u.user_id
                 WHERE m.receiver_id = ?
                 ORDER BY m.sent_at DESC";
$stmt = $conn->prepare($sql_messages);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result_messages = $stmt->get_result();

// Search user by email OR user_id
$user_search = null;
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . $conn->real_escape_string($_GET['search']) . "%";
    $sql_user = "SELECT user_id, username, email 
                 FROM Users 
                 WHERE email LIKE ? OR CAST(user_id AS CHAR) LIKE ?";
    $stmt_user = $conn->prepare($sql_user);
    $stmt_user->bind_param("ss", $search, $search);
    $stmt_user->execute();
    $user_search = $stmt_user->get_result();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Messages</title>
    <style>
        body {
            font-family: "Segoe UI", sans-serif;
            background-color: #f5f2ed; /* latte cream */
            margin: 0;
            padding: 0;
            color: #3e2c23; /* espresso brown */
        }
        .container {
            padding: 20px;
        }
        .usermsg {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(62, 44, 35, 0.2);
            padding: 25px;
            animation: fadeIn 0.6s ease;
        }
        h2.section-title {
            color: #5c4033;
            border-left: 6px solid #c19a6b; /* caramel accent */
            padding-left: 10px;
            margin-bottom: 20px;
        }
        .searchbar {
            margin: 15px 0 25px;
            text-align: center;
        }
        .searchbar input[type="text"] {
            padding: 10px 14px;
            border: 1px solid #c19a6b;
            border-radius: 6px 0 0 6px;
            background: #fff;
            font-size: 0.95em;
            color: #3e2c23;
            width: 280px;
        }
        .searchbar button {
            padding: 10px 16px;
            border: none;
            border-radius: 0 6px 6px 0;
            background: #c19a6b;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
        }
        .searchbar button:hover {
            background: #5c4033;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #e0d6cf;
            word-wrap: break-word;
        }
        th {
            background: #3e2c23;
            color: #f5f2ed;
            font-weight: 600;
            text-align: left;
        }
        tr:hover {
            background-color: #f0e6dd;
            transition: background 0.3s ease;
        }
        input[type="text"] {
            padding: 6px 10px;
            border: 1px solid #c19a6b;
            border-radius: 4px;
            font-size: 0.85em;
            width: 180px;
        }
        button {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            background: #c19a6b;
            color: #fff;
            font-size: 0.85em;
            cursor: pointer;
        }
        button:hover {
            background: #5c4033;
        }
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(10px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
<div class="container">
    <div class="usermsg">
        <h2 class="section-title">Messages Sent to Admin</h2>

        <!-- Search User -->
        <div class="searchbar">
            <form method="GET" action="user_messages.php">
                <input type="text" name="search" placeholder="Search by email " 
                value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <?php if ($user_search && $user_search->num_rows > 0): ?>
            <h3>Search Results</h3>
            <table>
                <tr><th>User</th><th>Email</th><th>Send Message</th></tr>
                <?php while ($u = $user_search->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($u['username']); ?></td>
                        <td><?php echo htmlspecialchars($u['email']); ?></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                <input type="text" name="reply_message" placeholder="Type message..." required>
                                <button type="submit">Send</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php elseif (isset($_GET['search'])): ?>
            <p>No user found with that email or ID.</p>
        <?php endif; ?>

        <!-- Messages Table -->
        <table>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Email</th>
                <th>Message</th>
                <th>Sent at</th>
                <th>Reply</th>
            </tr>
            <?php if ($result_messages && $result_messages->num_rows > 0) {
                while ($row = $result_messages->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['message_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['username']); ?></td>
                        <td><a href="mailto:<?php echo htmlspecialchars($row['email']); ?>">
                            <?php echo htmlspecialchars($row['email']); ?></a></td>
                        <td><?php echo htmlspecialchars($row['content']); ?></td>
                        <td><?php echo date("F j, Y g:i A", strtotime($row['sent_at'])); ?></td>
                        <td>
                            <form method="POST" style="margin:0;">
                                <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                <input type="text" name="reply_message" placeholder="Type reply..." required>
                                <button type="submit">Send</button>
                            </form>
                        </td>
                    </tr>
            <?php } } else { ?>
                <tr><td colspan="6">No messages found.</td></tr>
            <?php } ?>
        </table>
    </div>
</div>
</body>
</html>
