<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// ✅ Initialize here
$statusMsg = "";

// Handle delete
if (isset($_GET['delete'])) {

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $report_id = intval($_GET['delete']);

    // Get report details before deleting
    $sql_fetch = "
        SELECT r.report_id,
               r.user_id,
               r.item_id,
               r.report_type,
               i.category,
               i.description
        FROM Reports r
        JOIN Items i ON r.item_id = i.item_id
        WHERE r.report_id = ?
    ";

    $stmt = $conn->prepare($sql_fetch);
    $stmt->bind_param("i", $report_id);
    $stmt->execute();

    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if (!$row) {
        die("Report not found.");
    }

    // Save deletion history
    $sql_history = "
        INSERT INTO ReportHistory
        (report_ID, category, description, type, performed_by, timestamp)
        VALUES (?, ?, ?, ?, ?, NOW())
    ";

    $stmt = $conn->prepare($sql_history);
    $stmt->bind_param(
        "isssi",
        $row['report_id'],
        $row['category'],
        $row['description'],
        $row['report_type'],
        $_SESSION['user_id']
    );
    $stmt->execute();

    // Delete child records FIRST

    // Notifications
    $stmt = $conn->prepare(
        "DELETE FROM Notifications WHERE report_id=?"
    );
    $stmt->bind_param("i", $report_id);
    $stmt->execute();

    // Messages
    $stmt = $conn->prepare(
        "DELETE FROM Messages WHERE report_id=?"
    );
    $stmt->bind_param("i", $report_id);
    $stmt->execute();

    // Claims
    $stmt = $conn->prepare(
        "DELETE FROM Claims WHERE report_id=?"
    );
    $stmt->bind_param("i", $report_id);
    $stmt->execute();

    // Matched reports
    $stmt = $conn->prepare(
        "DELETE FROM MatchedReports WHERE id1=? OR id2=?"
    );
    $stmt->bind_param("ii", $report_id, $report_id);
    $stmt->execute();

    // Delete report
    $stmt = $conn->prepare(
        "DELETE FROM Reports WHERE report_id=?"
    );
    $stmt->bind_param("i", $report_id);
    $stmt->execute();

    // Delete linked item
    if (!empty($row['item_id'])) {

        $stmt = $conn->prepare(
            "DELETE FROM Items WHERE item_id=?"
        );
        $stmt->bind_param("i", $row['item_id']);
        $stmt->execute();
    }

    $_SESSION['statusMsg'] = "Report deleted successfully.";

    header("Location: moderate_reports.php");
    exit();
}

// Handle moderation action
if (isset($_GET['action']) && isset($_GET['id'])) {
    $action = $_GET['action'];
    $report_id = intval($_GET['id']);

    if ($action === 'approve' || $action === 'reject') {
        // Update the report status
        $sql = "UPDATE Reports SET status=? WHERE report_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $action, $report_id);
        $stmt->execute();

        // Fetch user_id for notification
        $sql_user = "SELECT user_id FROM Reports WHERE report_id=?";
        $stmt_user = $conn->prepare($sql_user);
        $stmt_user->bind_param("i", $report_id);
        $stmt_user->execute();
        $result_user = $stmt_user->get_result();
        $user_row = $result_user->fetch_assoc();

        if ($user_row) {
            // Send notification
            $sql_notify = "INSERT INTO Notifications (user_id, report_id, message) VALUES (?, ?, ?)";
            $stmt_notify = $conn->prepare($sql_notify);
            $notify_msg = "Your report #$report_id has been $action by admin.";
            $stmt_notify->bind_param("iis", $user_row['user_id'], $report_id, $notify_msg);
            $stmt_notify->execute();
        }

        $statusMsg = "Report #$report_id has been $action.";
    }
}

// Search logic
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = "%" . $conn->real_escape_string($_GET['search']) . "%";
    $sql = "SELECT r.report_id, u.username, i.category, i.description, i.location, i.photo_url, 
                   r.report_type, r.created_at, r.status
            FROM Reports r
            JOIN Users u ON r.user_id = u.user_id
            JOIN Items i ON r.item_id = i.item_id
            WHERE u.username LIKE ?
               OR r.report_id LIKE ? 
               OR i.category LIKE ? 
               OR i.description LIKE ?
               OR i.location LIKE ?
            ORDER BY r.created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $search, $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
  // DEFAULT QUERY  
    $sql = "SELECT r.report_id, u.username, i.category, i.description, i.location, i.photo_url, 
                   r.report_type, r.created_at, r.status
            FROM Reports r
            JOIN Users u ON r.user_id = u.user_id
            JOIN Items i ON r.item_id = i.item_id
            ORDER BY r.created_at DESC";
    $result = $conn->query($sql);
}

/* =========================
   EXPORT TO EXCEL
========================= */
if (isset($_GET['export']) && $_GET['export'] == 'excel') {

    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=LostAndFoundReports.xls");

   echo "
        <table border='1'>
        <tr>
            <th colspan='2' style='font-size:18px;background:#2c1716;color:white;'>
                LOST & FOUND MANAGEMENT SYSTEM
            </th>
        </tr>

        <tr>
            <td colspan='2'>
                Generated on: ".date("F j, Y g:i A")."
            </td>
        </tr>

        <tr>
            <th width='15%'>Report ID</th>
            <th width='85%'>Report Details</th>
        </tr>
        ";

    $exportQuery = "
        SELECT r.report_id,
               u.username,
               i.category,
               i.description,
               i.location,
               r.report_type,
               r.created_at,
               r.status,
               i.photo_url
        FROM Reports r
        JOIN Users u ON r.user_id=u.user_id
        JOIN Items i ON r.item_id=i.item_id
        ORDER BY r.created_at DESC
    ";

    $exportResult = $conn->query($exportQuery);

    while($row = $exportResult->fetch_assoc()){

    $details =
        "User: ".$row['username']."\n".
        "Category: ".$row['category']."\n".
        "Description: ".$row['description']."\n".
        "Location: ".$row['location']."\n".
        "Type: ".$row['report_type']."\n".
        "Status: ".$row['status']."\n".
        "Date Reported: ".date('F j, Y g:i A', strtotime($row['created_at']));

    echo "
    <tr>
        <td>".$row['report_id']."</td>
        <td>".nl2br($details)."</td>
    </tr>";
}

    echo "</table>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Moderate Reports</title>
    <link rel="stylesheet" type="text/css" href="../css/adminpage.css">
</head>
<style>
body {
    background-image: url('../css/itemsdark.png');

}
.modtab {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-family: Arial, sans-serif;
}

.modtab th {
    background-color: #2c1716; /* dark brown */
    color: #ffffff;            /* white text */
    padding: 12px;
    text-align: left;
    font-weight: bold;
}

.modtab td {
    background-color: #ffffff; /* white cells */
    color: #333333;            /* dark text for readability */
    padding: 12px;
    border: 1px solid #ccc;
}

.modtab tr:nth-child(even) td {
    background-color: #f9f9f9; /* subtle alternate row color */
}

.modtab tr:hover td {
    background-color: #f0e6e6; /* light brown tint on hover */
}

.allrep{
    color: #fdfdfd; /* caramel accent */
    
}

.toolbar{
    margin:15px 0;
    display:flex;
    gap:10px;
}

.btn-action{
    background:#2c1716;
    color:white;
    padding:10px 15px;
    border:none;
    border-radius:6px;
    text-decoration:none;
    cursor:pointer;
    font-weight:bold;
    font-size: 15px;
}

.btn-action:hover{
    background:#4a2926;
}

</style>
<body>
    
<div class="container">

    <div class="modport">
        <h2 class="allrep"> All Reports </h2>
        <div class="searchbar">
            <form method="GET" action="moderate_reports.php">
                <input type="text" name="search" placeholder="Search reports (username, category, description, location)" 
                       value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit">Search</button>
            </form>
        </div>
        <div class="toolbar">
            <button class="btn-action" onclick="printReports()">
                 Print Reports
            </button>

            <a href="moderate_reports.php?export=excel" class="btn-action">
                 Export Excel
            </a>
        </div>
        <table border="1" cellpadding="8" class="modtab">
            
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Category</th>
                <th>Description</th>
                <th>Location</th> <!-- NEW -->
                <th>Image</th>
                <th>Type</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>

            <?php if ($result->num_rows > 0) { ?>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['report_id']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['category']; ?></td>
                        <td><?php echo $row['description']; ?></td>
                        <td><?php echo !empty($row['location']) ? htmlspecialchars($row['location']) : 'N/A'; ?></td>
                        <td>
                            <?php if (!empty($row['photo_url'])) { ?>
                                <img src="../<?php echo htmlspecialchars($row['photo_url']); ?>" class="thumb">
                            <?php } else { ?>
                                No photo
                            <?php } ?>
                        </td>
                        <td><?php echo $row['report_type']; ?></td>
                        <td><?php echo date("F j, Y g:i A", strtotime($row['created_at'])); ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td>
                            <?php if ($row['status'] !== 'Claimed'){ ?>
                                <a class="action" href="edit_report.php?id=<?php echo $row['report_id']; ?>">Edit</a> |
                            <?php } ?>
                            <br>
                            <a class="action" href="moderate_reports.php?delete=<?php echo $row['report_id']; ?>"
                            onclick="return confirm('Are you sure you want to delete this report?')">Delete</a>
                            <br>
                            <?php if ($row['status'] === 'Unmatched') { ?>
                                <a class="action" href="match_items.php?id=<?php echo $row['report_id']; ?>">Match Item</a>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="10" style="text-align:center; padding:15px;">
                        No matching reports found.
                    </td>
                </tr>
            <?php } ?>


            <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['report_id']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['category']; ?></td>
                <td><?php echo $row['description']; ?></td>
                <td><?php echo !empty($row['location']) ? htmlspecialchars($row['location']) : 'N/A'; ?></td>
                <td>
                    <?php if (!empty($row['photo_url'])) { ?>
                        <img src="../<?php echo htmlspecialchars($row['photo_url']); ?>" 
                          alt="Item photo" class="thumb">
                    <?php } else { ?>
                        No photo
                    <?php } ?>
                </td>            
                <td><?php echo $row['report_type']; ?></td>
                <td>
                    <?php 
                   
                    echo date("F j, Y g:i A", strtotime($row['created_at'])); 
                    ?>
                </td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <?php if ($row['status'] !== 'Claimed'){ ?>
                    <a class="action" href="edit_report.php?id=<?php echo $row['report_id']; ?>">Edit</a> |
                    <?php } ?>  <br>
                    <a class="action" href="moderate_reports.php?delete=<?php echo $row['report_id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this report?')">Delete</a> |<br>
                    <?php if ($row['status'] === 'Unmatched') { ?>
                    <a class="action" href="match_items.php?id=<?php echo $row['report_id']; ?>">Match Item</a> 
                    <?php } ?>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>

<!--  ANIMATION FADE  -->
<script>
window.addEventListener("DOMContentLoaded", function() {
    const popup = document.querySelector(".popup");
    if (popup) {
        setTimeout(() => {
            popup.style.opacity = "0";
            popup.style.top = "-100px";
            popup.style.transition = "all 0.5s ease";
            setTimeout(() => popup.remove(), 500);
        }, 3000);
    }
});
</script>
<script>
function printReports(){

    let rows = document.querySelectorAll(".modtab tr");

    let table = `
    <table>
        <tr>
            <th style="width:15%">Report ID</th>
            <th>Report Details</th>
        </tr>
    `;

    for(let i=1;i<rows.length;i++){

        let cols = rows[i].querySelectorAll("td");

        if(cols.length < 9) continue;

        table += `
        <tr>
            <td>${cols[0].innerText}</td>

            <td>
                <strong>User:</strong> ${cols[1].innerText}<br>
                <strong>Category:</strong> ${cols[2].innerText}<br>
                <strong>Description:</strong> ${cols[3].innerText}<br>
                <strong>Location:</strong> ${cols[4].innerText}<br>
                <strong>Type:</strong> ${cols[6].innerText}<br>
                <strong>Date:</strong> ${cols[7].innerText}<br>
                <strong>Status:</strong> ${cols[8].innerText}
            </td>
        </tr>
        `;
    }

    table += "</table>";

    let win = window.open('', '', 'width=1000,height=700');

    win.document.write(`
    <html>
    <head>
        <title>Lost & Found Reports</title>

        <style>
        body{
            font-family:Arial,sans-serif;
            padding:20px;
        }

        table{
            width:100%;
            border-collapse:collapse;
        }

        th,td{
            border:1px solid #ccc;
            padding:10px;
            vertical-align:top;
        }

        th{
            background:#2c1716;
            color:white;
        }

        h2{
            text-align:center;
            color:#2c1716;
        }
        </style>

    </head>

    <body>

        <div style="text-align:center;">
            <img src="../css/logo.png"
                style="width:90px;height:auto;margin-bottom:10px;">

            <h2 style="margin:0;">
                LOST & FOUND MANAGEMENT SYSTEM
            </h2>

            <p>
                 ${new Date().toLocaleString()}
            </p>
        </div>

        <br>

        ${table}

    </body>
    </html>
    `);

    win.document.close();
    win.print();
}
</script>
</body>
</html>
