<?php
session_start();
include 'db.php';
//admin pass = viritagud!@#


$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM Users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password_hash'])) {

        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] == 'admin') {
            header("Location: admin/admin_dashboard.php");
        } else {
            header("Location: iframe.php");
        }
        exit();

    } else {

        $message = "Invalid email or password.";

    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Lost & Found</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="style">
    <img src="css/things.png">
    <div class="form">
    <form method="POST" class="loginform">
        <h2 class="login">Login</h2><br>

        <?php if (!empty($message)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <p>Email:<br> <input type="email" name="email" required><br></p>
        <p>Password:<br> <input type="password" name="password" required><br></p>
        <button type="submit">Login</button><br>
        
        <p class="link"> Don't have an account yet?<br><br><br><a href="register.php">Register</a></p>
        
    </form>

</div></div>
</body>
</html>
