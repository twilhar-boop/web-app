<?php
session_start();
include 'db.php';

// Require login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id   = (int)$_SESSION['user_id'];
$report_id = intval($_GET['id']);

// Fetch current report owned by this user (this is the "old" data snapshot)
$sql = "SELECT r.report_id, r.user_id, i.category, i.description, r.report_type, i.location, i.photo_url
        FROM Reports r
        JOIN Items i ON r.item_id = i.item_id
        WHERE r.report_id=? AND r.user_id=?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("SQL error in fetch: " . $conn->error);
}
$stmt->bind_param("ii", $report_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Access denied. You can only edit your own reports.");
}

$report = $result->fetch_assoc();

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category    = trim($_POST['category']);
    $description = trim($_POST['description']);
    $report_type = trim($_POST['report_type']);
    $location    = trim($_POST['location']);

    // Handle photo upload
    $photo_path = $report['photo_url']; // keep old photo if none uploaded
    if (!empty($_FILES['photo']['name'])) {
        $target_dir  = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        $target_file = $target_dir . time() . "_" . basename($_FILES["photo"]["name"]);

        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
            $photo_path = $target_file;
        } else {
            die("Error uploading photo.");
        }
    }

    // =========================
    // INSERT OLD VALUES INTO HISTORY
    // =========================
    $sql_hist = "INSERT INTO ReportHistory
                (report_ID, ACTION, performed_by, timestamp, category, description, type)
                VALUES (?, 'edit', ?, NOW(), ?, ?, ?)";
    $stmt_hist = $conn->prepare($sql_hist);
    if (!$stmt_hist) {
        die("History Prepare Error: " . $conn->error);
    }

    $old_type = strtolower($report['report_type']);
    if ($old_type !== 'found' && $old_type !== 'missing') {
        $old_type = null; // fallback if invalid
    }

    $stmt_hist->bind_param(
        "iisss",
        $report_id,
        $user_id,
        $report['category'],
        $report['description'],
        $old_type
    );

    if (!$stmt_hist->execute()) {
        die("History Insert Error: " . $stmt_hist->error);
    }

    // =========================
    // UPDATE REPORT WITH NEW VALUES
    // =========================
    $sql_item = "UPDATE Items 
                 JOIN Reports r ON Items.item_id = r.item_id
                 SET Items.category=?, Items.description=?, r.report_type=?, Items.location=?, Items.photo_url=?
                 WHERE r.report_id=? AND r.user_id=?";
    $stmt_item = $conn->prepare($sql_item);
    if (!$stmt_item) {
        die("SQL error in update: " . $conn->error);
    }
    $stmt_item->bind_param("sssssii", $category, $description, $report_type, $location, $photo_path, $report_id, $user_id);
    if (!$stmt_item->execute()) {
        die("Update Error: " . $stmt_item->error);
    }

    echo "<p style='margin-left: 40%; margin-top: 30%; color: white'>Report updated successfully! 
    <a href='my_reports.php' style='color: #ffc400; text-decoration: underline;'>Back to My Reports</a></p>";
    exit();
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Edit My Report</title>
    <link rel="stylesheet" type="text/css" href="css/submit.css">
</head>
<body>
<div class="container">
    <div class="useredit">
        <a href="my_reports.php">Back</a>
    <h2 class="edit">Edit your Report</h2>
    <form method="POST" enctype="multipart/form-data">
        <table class="form-table" >
            <tr>
                <td class="label">Category:</td>
                <td><input type="text" name="category" value="<?php echo htmlspecialchars($report['category']); ?>" required></td>
                <td class="label">Photo:</td>
                <td rowspan="2"> 
                    <input type="file" name="photo" accept="image/*"><br>
                    <?php if (!empty($report['photo_url'])): ?>
                        <img src="<?php echo htmlspecialchars($report['photo_url']); ?>" alt="Current Photo" style="max-width:200px; margin-top:10px;">
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td class="label">Description:</td>
                <td><textarea name="description" required><?php echo htmlspecialchars($report['description']); ?></textarea></td>
                
            </tr>
            <tr>

            </tr>
            <tr>
                <td class="label">Location:</td>
                <td><input type="text" name="location" value="<?php echo htmlspecialchars($report['location']); ?>" required></td>
                <td class="label">Type:</td>
                <td>
                    <select name="report_type">
                        <option value="missing" <?php if($report['report_type']=='missing') echo 'selected'; ?>>Missing</option>
                        <option value="found" <?php if($report['report_type']=='found') echo 'selected'; ?>>Found</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="4"><button class="useredbtn" type="submit">Update Report</button></td>
            </tr>
        </table>
    </form></div>
</div>
</body>
</html>
