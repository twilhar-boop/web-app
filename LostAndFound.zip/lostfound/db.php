<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "lost_and_foundv2";
//WilharDataBase!@# 

$conn = new mysqli($host, $user, $pass, $db);

// if connection fails, stop execution and show error, connect_error is a property of mysqli that contains the 
// error message from the last connection attempt and built-in function die() is used to output a message and 
// terminate the current script. In this case, if the connection to the database fails, it will output "Connection failed: 
// " followed by the specific error message from the connection attempt,
//  and then stop executing any further code. This is a common way to handle database connection errors in PHP.
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error);
}
?>
