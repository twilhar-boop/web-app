<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
$user_id = $_SESSION['user_id'];

// Fetch reports
$sql = "
SELECT
    r.report_id,
    r.report_type,
    r.status,
    r.created_at,
    i.category,
    i.description,
    i.location,
    i.photo_url
FROM Reports r
JOIN Items i ON r.item_id = i.item_id
WHERE r.user_id=?
ORDER BY r.created_at DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$message = ""; // feedback banner
if (isset($_SESSION['statusMsg'])) {
    $message = $_SESSION['statusMsg'];
    unset($_SESSION['statusMsg']);
}

/* =========================
   DELETE REPORT
========================= */
if (isset($_GET['delete'])) {
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
    $report_id = (int)$_GET['delete'];

    try {
        $conn->begin_transaction();

        // Fetch report and verify ownership
        $sql_fetch = "
            SELECT r.report_id,
                   r.user_id,
                   r.item_id,
                   r.report_type,
                   i.category,
                   i.description
            FROM Reports r
            JOIN Items i ON r.item_id = i.item_id
            WHERE r.report_id = ?
              AND r.user_id = ?
        ";
        $stmt = $conn->prepare($sql_fetch);
        $stmt->bind_param("ii", $report_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row    = $result->fetch_assoc();

        if (!$row) {
            throw new Exception("Access denied or report not found.");
        }

        // Save deletion history
        $sql_history = "
            INSERT INTO ReportHistory
                (report_ID, ACTION, performed_by, category, description, type, timestamp)
            VALUES (?, 'delete', ?, ?, ?, ?, NOW())
        ";
        $stmt = $conn->prepare($sql_history);
        $stmt->bind_param(
            "iisss",
            $row['report_id'],
            $user_id,
            $row['category'],
            $row['description'],
            $row['report_type']
        );
        $stmt->execute();

        // Cascade deletes
        $stmt = $conn->prepare("DELETE FROM Notifications WHERE report_id=?");
        $stmt->bind_param("i", $report_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM Messages WHERE report_id=?");
        $stmt->bind_param("i", $report_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM Claims WHERE report_id=?");
        $stmt->bind_param("i", $report_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM MatchedReports WHERE id1=? OR id2=?");
        $stmt->bind_param("ii", $report_id, $report_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM Reports WHERE report_id=?");
        $stmt->bind_param("i", $report_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM Items WHERE item_id=?");
        $stmt->bind_param("i", $row['item_id']);
        $stmt->execute();

        // Commit transaction
        $conn->commit();
        $_SESSION['statusMsg'] = "Report deleted successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['statusMsg'] = "Unable to delete report.";
        error_log($e->getMessage());
    }

    header("Location: my_reports.php");
    exit();
}


?>
<!DOCTYPE html>
<html>
<head>
    <title>My Reports</title>
    <link rel="stylesheet" href="css/submit.css">
    <style>
.submitform {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 15px;
}

.report-card {
    border: 1px solid #ccc;
    border-radius: 8px;
    padding: 12px;
    background: #111;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

.report-card h3 {
    margin: 0 0 8px;
    font-size: 1.1em;
    color: #fff;
}

.report-photo {
    max-width: 100%;
    height: auto;
    border-radius: 6px;
    margin-bottom: 8px;
}

.report-card p {
    margin: 4px 0;
    font-size: 0.9em;
    color: #ddd;
}

.report-actions {
    margin-top: auto;
    display: flex;
    gap: 8px;
}

.report-actions a {
    text-decoration: none;
    padding: 5px 10px;
    background: #28a725;
    color: white;
    border-radius: 4px;
    font-size: 0.85em;
}

.report-actions .delete-btn {
    background: #dc3545;
}

    </style>
</head>
<body>
  

    <div class="submitform">
        <h1>My Reports</h1>
        <br>

        <!-- Notification Banner -->
        <?php if (!empty($message)): ?>
            <div class="notif-banner <?php echo ($message === 'Access denied. You can only delete your own reports.') ? 'error' : ''; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <?php while($row = $result->fetch_assoc()): ?>
    <div class="report-card">
        <h3><?php echo htmlspecialchars($row['category']); ?></h3>
        <?php if (!empty($row['photo_url'])): ?>
            <img src="<?php echo htmlspecialchars($row['photo_url']); ?>" class="report-photo">
        <?php endif; ?>
        <p><strong>Description:</strong> <?php echo htmlspecialchars($row['description']); ?></p>
        <p><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
        <p><strong>Type:</strong> <?php echo htmlspecialchars($row['report_type']); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($row['status']); ?></p>
        <p><strong>Created:</strong> <?php echo htmlspecialchars($row['created_at']); ?></p>

        <?php if (strcasecmp(trim($row['status']), 'Claimed') !== 0): ?>
            <div class="report-actions">
                <a href="user_edit_report.php?id=<?php echo $row['report_id']; ?>">Edit</a>
                <a href="my_reports.php?delete=<?php echo $row['report_id']; ?>" 
                onclick="return confirm('Are you sure you want to delete this report?');" 
                class="delete-btn">Delete</a>
            </div>
<?php endif; ?>

    </div>
<?php endwhile; ?>

    </div>
</body>
</html>
