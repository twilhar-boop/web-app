<?php
include 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    // Hash the password directly
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO Users (username, email, password_hash) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sss", $username, $email, $password_hash);

    if ($stmt->execute()) {
        echo "Registration successful. <a href='index.php'>Login here</a>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>LOST AND FOUND</title>
    <link rel="stylesheet" href="css/register.css">
</head>
<body>
    <div class="reg">
        <form method="POST">
            <h2>Register Account</h2>
            <p>Username: <br>
                <input type="text" name="username" required><br>
            </p>
            <p>Email: <br>
                <input type="email" name="email" required><br>
            </p>
            <p>Password: <br>
                <input type="password" name="password" required><br>
            </p>
            <button class="register" type="submit">Register</button>
            <p class="link">Already have an Account?</p>
            <a href="login.php">LogIn</a>
        </form>
    </div>
</body>
</html>
